<?php

namespace YahnisElsts\AdminMenuEditor\Customizable\Settings;

class FloatSetting extends NumericSetting {
	protected $dataType = 'float';
}