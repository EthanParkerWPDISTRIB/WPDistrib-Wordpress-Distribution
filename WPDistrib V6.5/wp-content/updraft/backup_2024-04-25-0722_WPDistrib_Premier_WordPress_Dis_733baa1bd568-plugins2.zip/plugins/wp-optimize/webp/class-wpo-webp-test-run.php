<?php

if (!defined('WPO_VERSION')) die('No direct access allowed');

if (!class_exists('WPO_WebP_Test_Run')) :
	/**
	 * Test run
	 */
class WPO_WebP_Test_Run {

	/**
	 * Get a test result object OR false, if tests cannot be made.
	 *
	 * @return object|false
	 */
	public static function get_converter_status() {
		$source = WPO_PLUGIN_MAIN_PATH . 'images/logo/wpo_logo_small.png';
		$upload_dir = wp_upload_dir();
		$destination =  $upload_dir['basedir']. '/wpo/images/wpo_logo_small.png.webp';

		$converters = array(
			// 'cwebp',
			'vips',
			'imagemagick',
			'graphicsmagick',
			'ffmpeg',
			'wpc',
			'ewww',
			'imagick',
			'gmagick',
			'gd',
		);
		$working_converters = array();
		$errors = array();

		foreach ($converters as $converter) {
			$converter_id = $converter;
			try {
				WPO_WebP_Utils::perform_webp_conversion($converter_id, $source, $destination);
				$working_converters[] = $converter_id;
				// Copying source file to `uploads` folder. To be used test redirection
				// We're doing it here, to make sure folders already exists `/wpo/images/`
				copy($source, $upload_dir['basedir'] . '/wpo/images/wpo_logo_small.png');
			} catch (\Exception $e) {
				$errors[$converter_id] = $e->getMessage();
			}
		}

		return array(
			'working_converters' => $working_converters,
			'errors' => $errors,
		);
	}
}

endif;
